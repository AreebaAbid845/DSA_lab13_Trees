#include <iostream>
using namespace std;

class Node
{
	public:
		
		char data;
		Node *left;
		Node *right;
	
};

class Tree
{
	
	Node *root;
	public:
	Tree(char key)
	{
		root = new Node;
        root->data = key;
        root->left = NULL;
        root->right = NULL;
	}
	
	Tree()
	{
		root = NULL;
	}
	
	void setRoot(Node* node)
    {
        root = node;
    }
    
	void traversePreOrder(Node *temp)  //TO JUST DO THE TRAVERSING
	{
		if(temp!=NULL)
		{
			cout<<temp->data<<endl;
			traversePreOrder(temp->left);
			traversePreOrder(temp->right);
		}
	}
	
	void traverseInOrder(Node *temp)
	{
		if(temp!=NULL)
		{
			traverseInOrder(temp->left);
			cout<<temp->data<<endl;
			traverseInOrder(temp->right);
		}
	}
	
	void traversePostOrder(Node *temp)
	{
		if(temp!=NULL)
		{
			traversePostOrder(temp->left);
			traversePostOrder(temp->right);
			cout<<temp->data<<endl;
			
		}
	}
	
	void traverseInOrder()  //these are created for passing root to the method of traversal
    {
        traverseInOrder(root);
        
    }

    void traversePostOrder()
    {
        traversePostOrder(root);
    }
};

int main()
{
	Node *root, *n1, *n2, *n3, *n4, *n5, *n6, *n7, *n8;
    root = new Node;
    n1 = new Node;
    n2 = new Node;
    n3 = new Node;
    n4 = new Node;
    n5 = new Node;
    n6 = new Node;
    n7 = new Node;
    n8 = new Node;
	
    root->data = 'c';  // Added data to the root
    root->left = n1;
    root->right = n2;

    n1->data = 's';
    n1->left = n3;
    n1->right = n4;

    n2->data = 'a';
    n2->left = n5;
    n2->right = n6;

    n3->data = 'q';
    n3->left = n7;
    n3->right = nullptr;

    n4->data = 'e';
    n4->left = nullptr;
    n4->right = n8;

    n5->data = 'd';
    n5->left = nullptr;
    n5->right = nullptr;

    n6->data = 'f';
    n6->left = nullptr;
    n6->right = nullptr;

    n7->data = 'v';
    n7->left = nullptr;
    n7->right = nullptr;

    n8->data = 'z';
    n8->left = nullptr;
    n8->right = nullptr;

    Tree t1;
    t1.setRoot(root);  //passes our root to the system

    cout << "Inorder :" << endl;
    t1.traverseInOrder();

    cout << "Post-order:" << endl;
    t1.traversePostOrder();
	
	
}
