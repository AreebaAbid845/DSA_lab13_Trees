// notes on dfs and bfs

/*dfs is when we traverse through the depth of one of the subtree of branches

dfs means going through for example only the left side of the tree ...stack used for recursion
when reaches depth and when it gets to null...backtracking occurs which means going back to the root node from where it
can start traversing to the right side

we can use postorder, inorder and preorder in this





*/


/*
bfs is also called level-order traversal, uses queues

processes nodes at each level and by the help of queues it dequeues the parent node and enqueues the child nodes



*/